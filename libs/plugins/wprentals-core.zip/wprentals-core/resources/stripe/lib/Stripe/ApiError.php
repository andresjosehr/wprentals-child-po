<?php

class Stripe_ApiError extends Stripe_Error
{
}
